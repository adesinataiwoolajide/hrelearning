    <?php $__env->startSection("content"); ?>
    <div class="clearfix"></div>
    <div class="content-wrapper">
   		<div class="container-fluid">
   			<div class="row pt-2 pb-2">
		        <div class="col-sm-9">
				    <ol class="breadcrumb">
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('allocate', $partnering->id)); ?>">Allocate Course</a></li>
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('allocate.courselist', $partnering->id)); ?>">Allocated Course List</a></li>
			            <li class="breadcrumb-item"><a href="<?php echo e(route('partner.index')); ?>">View All Partners</a></li>
			            
			            <li class="breadcrumb-item active" aria-current="page">Adding Course To Partners</li>
			         </ol>
			   	</div>
			</div>
   			<div class="row">
		    	<div class="col-lg-12">

		    		<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		          	<div class="card">
		            	<div class="card-header"><i class="fa fa-table"></i> Please Fill The Below Form To Add Course To <?php echo e($partnering->partner_name); ?></div>
	            		<div class="card-body">
	            			<form action="<?php echo e(route('allocate.store')); ?>" method="POST" enctype="multipart/form-data">
	            				<?php echo e(csrf_field()); ?>

		            			
		            			<div class="form-group row ">
		            				<div class="col-sm-3">
					                    <input type="text" class="form-control" readonly value="<?php echo e($partnering->partner_name); ?>">
					                    <input type="hidden" class="form-control" name="partner_id" required value="<?php echo e($partnering->id); ?>">
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('partner_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('partner_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                 </div>
					                <div class="col-sm-3">
					                    <select class="form-control" required="" name="course_id"  id="course_id">>
					                    	<option value="">-- Select The Course --</option>
					                    	<option value=""></option>
					                    	<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    		<?php $__currentLoopData = getCourseCategory($list->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  	
						                    		<option value="<?php echo e($list->id); ?>">
						                    			<?php echo e($list->course_name . " For ". $show->category_name); ?>

						                    		</option>
					                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('course_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('course_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>
					                
					                <div class="col-sm-3">
					                    <select class="form-control" required="" name="instructor_id">
					                    	<option value="">-- Select The Instructor --</option>
					                    	<option value=""></option>
					                    	<?php $__currentLoopData = listInstructor(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    		<option value="<?php echo e($lists->id); ?>"><?php echo e($lists->name); ?></option>
					                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('instructor_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('instructor_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>
					                

					                 <div class="col-sm-3" align="">
					                      <button type="submit" class="btn btn-primary">ALLOCATE COURSE</button>
					                 </div>
						            
					            </div>
				            </form>
		            	</div>
		            </div>
		        </div>
		    </div>
			 <div class="row">
		    	<div class="col-lg-12">
		          	<div class="card">
		          		<?php if(count($all) ==0): ?>
            				<div class="card-header" align="center" style="color: red"><i class="fa fa-table"></i> The Course Allocation is Empty</div>
            				<h3><p style="color: red" align="center"></p> </h3>
            			<?php else: ?>
			            	<div class="card-header"><i class="fa fa-table"></i> List of Allocated Courses For <?php echo e($partnering->partner_name); ?></div>
		            		<div class="card-body">

		              			<div class="table-responsive">
		              				<table id="example" class="table table-bordered">
		              					<thead>
						                    <tr>
						                       <th>Serial Number</th>
						                        <th>Course Name</th>
						                        <th>Course Material</th>
						                        <th>Course Category</th>
						                        <th>Instructor</th>
						                       
						                    </tr>
						                </thead>

						                <tfoot>
						                    <tr>
						                        <th>Serial Number</th>
						                        <th>Course Name</th>
						                        <th>Course Material</th>
						                        <th>Course Category</th>
						                        <th>Instructor</th>
						                        
						                    </tr>
						                </tfoot>
						                <tbody>
						                	<?php $number =1; ?>
						                	<?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <tr>
							                        <td>
							                        	<?php echo e($number); ?>

							                        	<a href="<?php echo e(route('allocate.delete', $part->id)); ?>" class="btn btn-danger">
							                        		<i class="fa fa-trash-o"></i>
							                        	</a>
							                        	<a href="" class="btn btn-success">
							                        		<i class="fa fa-pencil"></i>
							                        	</a>

							                        </td>
							                        	<?php $__currentLoopData = gettingCourses($part->course_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ropo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									                        <td><?php echo e($ropo->course_name); ?></td>
									                       	 <td>
									                        	<img src="<?php echo e(asset('styling/book.png')); ?>" class="logo-icon" alt="logo icon">
									                        	<a href="<?php echo e(asset('course-materials/'.$ropo->course_material)); ?>" target="_blank"> <?php echo e($ropo->course_material); ?></a>
									                        </td>
									                       	<td>
									                       		<?php $__currentLoopData = getCourseCategory($ropo->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									                        		<?php echo e($show->category_name); ?>

									                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									                       	</td>
									                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							                       	<td>
							                       		<?php $__currentLoopData = usersDetails($part->instructor_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $low): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                       			<?php echo e($low->name); ?>

							                       		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							                       	</td>
							                       
							                        
							                    </tr><?php
							                    $number++; ?>
							                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                </tbody>
						               
		              				</table>
		              			</div>
	              			<?php endif; ?>
	              		</div>
	             
	              	</div>
	            </div>
	        </div>
	     </div>
	</div>
	
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.newheader", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>