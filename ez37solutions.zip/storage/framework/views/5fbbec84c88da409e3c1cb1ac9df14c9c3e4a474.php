    <?php $__env->startSection("content"); ?>
    <div class="clearfix"></div>
    <div class="content-wrapper">
   		<div class="container-fluid">
   			<div class="row pt-2 pb-2">
		        <div class="col-sm-9">
				    <ol class="breadcrumb">
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('user.create')); ?>">Add User</a></li>
			            <li class="breadcrumb-item active" aria-current="page">Saved Partner</li>
			         </ol>
			   	</div>
			</div>
   			<div class="row">
		    	<div class="col-lg-12">

		    		<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		          	<div class="card">
		            	<div class="card-header"><i class="fa fa-table"></i> Please Fill The Below Form To Add The User Details</div>
	            		<div class="card-body">
	            			<form action="<?php echo e(route('user.save')); ?>" method="POST" enctype="multipart/form-data">
	            				<?php echo e(csrf_field()); ?>

		            			
		            			<div class="form-group row ">
		            				<div class="col-sm-3">
					                    <input type="text" class="form-control" name="name" required placeholder="Enter Name">
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('name')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('name')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                 </div>
					                <div class="col-sm-3">
					                    <input type="email" class="form-control"  name="email" placeholder="Enter E-Mail" min="4" required>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('email')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('email')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>

					                <div class="col-sm-3">
					                	<?php $list = array("Admin", "Instructor", "Student")    ?>
					                   	<select class="form-control" name="is_admin" required>
					                   		<option value="">-- User Type --</option>
					                   		<option value=""></option>
					                   		<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $used): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                   			<option value="<?php echo e($used); ?>"><?php echo e($used); ?></option>
					                   		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                   	</select>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('is_admin')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('is_admin')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>

					                <div class="col-sm-3">
					                    <input type="password" class="form-control" name="password" required placeholder="Enter Password">
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('password')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('password')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                 </div>
					                 <input type="hidden" name="status" value="1">
					                 <div class="col-sm-12" align="center">
					                      <button type="submit" class="btn btn-primary">ADD THE USER DETAILS</button>
					                 </div>
						            
					            </div>
				            </form>
		            	</div>
		            </div>
		        </div>
		    </div>
			 <div class="row">
		    	<div class="col-lg-12">
		          	<div class="card">
		          		<?php if(count($user) ==0): ?>
			            	<div class="card-header" align="center" style="color: red"><i class="fa fa-table"></i> The List is Empty
			            	</div>

			            <?php else: ?>
			            	<div class="card-header"><i class="fa fa-table"></i> List of Saved Users</div>
		            		<div class="card-body">
		              			<div class="table-responsive">
		              				<table id="example" class="table table-bordered">
		              					<thead>
						                    <tr>
						                        <th>Serial Number</th>
						                        <th>Full Name</th>
						                        <th>E-Mail</th>
						                        <th>User Type</th>
						                        <th>Operations</th>
						                    </tr>
						                </thead>

						                <tfoot>
						                    <tr>
						                        <th>Serial Number</th>
						                        <th>Full Name</th>
						                        <th>E-Mail</th>
						                        <th>User Type</th>
						                        <th>Operations</th>
						                    </tr>
						                </tfoot>
						                <tbody>
						                	<?php $number =1; ?>
						                	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <tr>
							                        <td><?php echo e($number); ?>

							                        	<a href="<?php echo e(route('user.delete', $users->id)); ?>" class="btn btn-danger"><i class="fa fa-trash-o"></i></a>
							                        	<a href="" class="btn btn-success"><i class="fa fa-pencil"></i></a>
							                        </td>
							                        <td><?php echo e($users->name); ?></td>
							                        <td><?php echo e($users->email); ?></td>
							                        <td><?php echo e(interpreteRole($users->is_admin)); ?></td>
							                        <td><?php echo e(interpreteRoleStatus($users->status)); ?></td>
							                    </tr><?php
							                    $number++; ?>
							                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                </tbody>
						               
		              				</table>
		              			</div>
		              		</div>
		             	<?php endif; ?>
	              	</div>
	            </div>
	        </div>
	     </div>
	</div>


    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.newheader", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>