    <?php $__env->startSection("content"); ?>
    <div class="clearfix"></div>
    <div class="content-wrapper">
   		<div class="container-fluid">
   			<div class="row pt-2 pb-2">
		        <div class="col-sm-9">
				    <ol class="breadcrumb">
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
				    	<li class="breadcrumb-item"><a href="<?php echo e(route('partner.courseallocation', $partnering->id)); ?>">Allocate Course</a></li>
			            <li class="breadcrumb-item"><a href="<?php echo e(route('partner.index')); ?>">View Partners</a></li>
			            
			            <li class="breadcrumb-item active" aria-current="page">Saved Partners</li>
			         </ol>
			   	</div>
			</div>
   			<div class="row">
		    	<div class="col-lg-12">

		    		<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		          	<div class="card">
		            	<div class="card-header"><i class="fa fa-table"></i> Please Fill The Below Form To Add The Partner Course </div>
	            		<div class="card-body">
	            			<form action="<?php echo e(route('partner.store')); ?>" method="POST" enctype="multipart/form-data">
	            				<?php echo e(csrf_field()); ?>

		            			
		            			<div class="form-group row ">
		            				<div class="col-sm-3">
					                    <input type="text" class="form-control" readonly value="<?php echo e($partnering->partner_name); ?>">
					                    <input type="hidden" class="form-control" name="partner_id" required value="<?php echo e($partnering->partner_name); ?>">
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('partner_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('partner_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                 </div>
					                <div class="col-sm-3">
					                    <select class="form-control" required="" name="course"  id="course">>
					                    	<option value="">-- Select The Course --</option>
					                    	<option value=""></option>
					                    	<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    		<?php $__currentLoopData = getCourseCategory($list->category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                        		
							                        	
					                    		<option value="<?php echo e($list->id); ?>">
					                    			<?php echo e($list->course_name . " For ". $show->category_name); ?>

					                    		</option>
					                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('category_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('category_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>
					                
					                <div class="col-sm-3">
					                    <select class="form-control" required="" name="category_id">
					                    	<option value="">-- Select The Instructor --</option>
					                    	<option value=""></option>
					                    	<?php $__currentLoopData = listInstructor(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                    		<option value="<?php echo e($lists->id); ?>"><?php echo e($lists->name); ?></option>
					                    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                    </select>
					                    <span style="color: red">** This Field is Required **</span>
					                     <?php if($errors->has('category_id')): ?>
                                            <div class="alert alert-danger alert-dismissible" role="alert">
										        <button type="button" class="close" data-dismiss="alert">&times;</button>
										        <div class="alert-icon contrast-alert">
										            <i class="fa fa-check"></i>
										        </div>
										        <div class="alert-message">
										            <span><strong>Error!</strong> <?php echo e($errors->first('category_id')); ?> !</span>
										        </div>
										    </div>
                                        <?php endif; ?>  
					                </div>
					                

					                 <div class="col-sm-3" align="">
					                      <button type="submit" class="btn btn-primary">ALLOCATE COURSE</button>
					                 </div>
						            
					            </div>
				            </form>
		            	</div>
		            </div>
		        </div>
		    </div>
			 <div class="row">
		    	<div class="col-lg-12">
		          	<div class="card">
		          		
			            	<div class="card-header"><i class="fa fa-table"></i> List of Saved partners</div>
		            		<div class="card-body">
		              			<div class="table-responsive">
		              				<table id="example" class="table table-bordered">
		              					<thead>
						                    <tr>
						                        <th>Serial Number</th>
						                        <th>Partner Name</th>
						                        <th>Partner Logo</th>
						                        <th> Operations</th>
						                    </tr>
						                </thead>

						                <tfoot>
						                    <tr>
						                        <th>Serial Number</th>
						                        <th>Partner Name</th>
						                        <th>Partner Logo</th>
						                        <th> Operations</th>
						                    </tr>
						                </tfoot>
						                <tbody>
						                	<?php $number =1; ?>
						                	<?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partners): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							                    <tr>
							                        <td>
							                        	<?php echo e($number); ?>

							                        	<a href="<?php echo e(route('partner.delete', $partners->id)); ?>" class="btn btn-danger">
							                        		<i class="fa fa-trash-o"></i>
							                        	</a>
							                        	<a href="" class="btn btn-success">
							                        		<i class="fa fa-pencil"></i>
							                        	</a>

							                        </td>
							                        <td><?php echo e($partners->partner_name); ?></td>
							                        <td>
							                        	<img src="<?php echo e(asset('partner-logo/'.$partners->partner_logo)); ?>" class="logo-icon" alt="logo icon" style="width: 50px; height: 50px"> 
							                        	
							                        </td>
							                        <td>
							                        	<a href="" class="btn btn-danger">Allocate Course</a>
							                        	<a href="Add-staff" class="btn btn-primary">Add Staff</a>
							                        </td>
							                        
							                    </tr><?php
							                    $number++; ?>
							                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						                </tbody>
						               
		              				</table>
		              			</div>
		              		</div>
		             
	              	</div>
	            </div>
	        </div>
	     </div>
	</div>
	
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.newheader", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>