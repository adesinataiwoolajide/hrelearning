<div class="mdk-drawer js-mdk-drawer" id="default-drawer">
    <div class="mdk-drawer__content ">
        <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden" data-perfect-scrollbar>
            <div class="sidebar-p-y">
                <div class="sidebar-heading">APPLICATIONS</div>
                <ul class="sidebar-menu sm-active-button-bg">
                    <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="<?php echo e(route('coursecategory.index')); ?>">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Course Category
                        </a>
                    </li>
                    <li class="sidebar-menu-item active">
                        <a class="sidebar-menu-button" href="">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">school</i> Course
                        </a>
                    </li>
                    <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Partners
                        </a>
                    </li>
                    <li class="sidebar-menu-item active">
                        <a class="sidebar-menu-button" href="">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">school</i> Instructor
                        </a>
                    </li>
                    <li class="sidebar-menu-item">
                        <a class="sidebar-menu-button" href="">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Student
                        </a>
                    </li>
                    <li class="sidebar-menu-item active">
                        <a class="sidebar-menu-button" href="">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons ">school</i> Payments
                        </a>
                    </li>
                    <li class="sidebar-menu-item active">
                        <a class="sidebar-menu-button" href="<?php echo e(route("admin.logout")); ?>">
                            <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons ">school</i> Log Out
                        </a>
                    </li>
                    
                </ul>
                <!-- Account menu -->
                
            </div>
        </div>
    </div>
</div>