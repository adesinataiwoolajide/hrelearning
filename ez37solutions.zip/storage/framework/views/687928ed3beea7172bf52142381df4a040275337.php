<div id="header" data-fixed class="mdk-header js-mdk-header mb-0">
    <div class="mdk-header__content">
        
        <!-- Navbar -->
        <nav id="default-navbar" class="navbar navbar-expand navbar-dark bg-primary m-0">
            <div class="container-fluid">
                <!-- Toggle sidebar -->
                <button class="navbar-toggler d-block" data-toggle="sidebar" type="button">
                    <span class="material-icons">menu</span>
                </button>

                <!-- Brand -->
                <a href="" class="navbar-brand">
                    <span class="d-none d-xs-md-block">EZ37Solutions</span>
                </a>

                <ul class="nav navbar-nav navbar-nav-stats d-none d-md-flex flex-nowrap">
                    <li class="nav-item">
                        <div class="nav-stats">$591 <small>GROSS</small></div>
                    </li>
                    <li class="nav-item">
                        <div class="nav-stats">$31 <small>TAXES</small></div>
                    </li>
                    <li class="nav-item mr-3">
                        <div class="nav-stats">$560 <small>NET</small></div>
                    </li>
                </ul>

                <div class="flex"></div>
                    <!-- User dropdown -->
                    <li class="nav-item dropdown ml-1 ml-md-3">
                        <a class="dropdown-item" href="<?php echo e(route("admin.logout")); ?>">
                            <i class="material-icons">lock</i>
                        </a>
                        
                    </li>
                    <!-- // END User dropdown -->
                </ul>
            </div>
        </nav>
        <!-- // END Navbar -->

    </div>
</div>